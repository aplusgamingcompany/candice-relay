# Candice Relay

This is a small Node.js server that listens for Twilio Voice calls and forwards the spoken input to ElevenLabs, then returns the AI-generated voice response using TwiML.

## Setup

1. Install dependencies: `npm install`
2. Create a `.env` file with the following:
```
ELEVENLABS_API_KEY=your-api-key
ELEVENLABS_VOICE_ID=your-voice-id
```
3. Deploy to Render or run locally with `node server.js`