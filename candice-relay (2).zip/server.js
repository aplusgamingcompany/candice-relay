const express = require('express');
const twilio = require('twilio');
const axios = require('axios');
require('dotenv').config();

const app = express();
app.use(express.urlencoded({ extended: true }));

const voiceResponse = (text) => {
    return `<?xml version="1.0" encoding="UTF-8"?>
<Response>
    <Say voice="Polly.Joanna">${text}</Say>
</Response>`;
};

app.post('/voice', async (req, res) => {
    const userSpeech = req.body.SpeechResult || "Hello";
    const elePayload = {
        text: userSpeech,
        voice: process.env.ELEVENLABS_VOICE_ID,
        model_id: "eleven_monolingual_v1",
        voice_settings: {
            stability: 0.5,
            similarity_boost: 0.75
        }
    };

    try {
        const aiResponse = await axios.post(
            "https://api.elevenlabs.io/v1/text-to-speech",
            elePayload,
            {
                headers: {
                    "xi-api-key": process.env.ELEVENLABS_API_KEY,
                    "Content-Type": "application/json"
                }
            }
        );
        const aiText = aiResponse.data?.text || "Hi, this is Candice. How can I help you?";
        res.set('Content-Type', 'text/xml');
        res.send(voiceResponse(aiText));
    } catch (err) {
        res.set('Content-Type', 'text/xml');
        res.send(voiceResponse("Sorry, I couldn't process that."));
    }
});

app.listen(process.env.PORT || 3000, () => {
    console.log("Candice voice relay running.");
});