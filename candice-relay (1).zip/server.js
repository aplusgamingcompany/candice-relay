const WebSocket = require('ws');
const http = require('http');
require('dotenv').config();

const ELEVENLABS_API_KEY = process.env.ELEVENLABS_API_KEY;
const PORT = process.env.PORT || 8080;

const server = http.createServer();
const wss = new WebSocket.Server({ server });

console.log("Relay server starting...");

wss.on('connection', function connection(twilioSocket) {
    console.log("Twilio call connected.");

    twilioSocket.on('message', async function incoming(data) {
        const message = JSON.parse(data);

        // Handle media stream
        if (message.event === 'media') {
            // Simulate Candice speaking back
            const response = {
                event: 'media',
                media: {
                    payload: '...' // This would be replaced with audio generated via ElevenLabs
                }
            };
            twilioSocket.send(JSON.stringify(response));
        }
    });

    twilioSocket.on('close', () => {
        console.log('Connection closed');
    });
});

server.listen(PORT, () => {
    console.log(`Server is listening on port ${PORT}`);
});